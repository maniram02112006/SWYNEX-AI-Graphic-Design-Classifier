# Graphic Design Classifier — Sample Dataset

This starter ZIP contains 20 cropped sample poster images organized into five folders:
- `cinematic/`
- `minimalist/`
- `typography/`
- `sports/`
- `vintage/`

Each folder contains four illustrative samples. `labels.csv` maps each image path to its intended category. `dataset_preview.jpg` shows the generated contact sheet.

## Important limitations
- These are AI-generated illustrative examples cropped from a single contact sheet, not a large, independently collected dataset.
- They are useful for organizing your project and demonstrating the folder/label structure, but are NOT sufficient for reliable model training or an honest performance evaluation.
- Some samples may contain visual or text artifacts and may mix design styles.
- For model evaluation, collect a larger and more varied set of appropriately licensed images, label them carefully, and split training and test images before training.
- Do not claim accuracy or model results from this sample pack alone.

## Folder structure
```text
graphic_design_classifier_dataset/
├── cinematic/
├── minimalist/
├── typography/
├── sports/
├── vintage/
├── labels.csv
└── dataset_preview.jpg
```
